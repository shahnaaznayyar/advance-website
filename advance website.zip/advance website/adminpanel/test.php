<?php
echo$pass='hello';
echo$encrypt=md5($pass);
?>