
<?php
include("index.php");
include("include/connect.php");
$edit_id=@$_GET['edit'];
$query="select* from posts where post_id='$edit_id'";
$run=mysql_query($query);
if(!$run){
    echo "Could not successfully run query ($query) from DB: " . mysql_error();
    exit;
}
while($row=mysql_fetch_array($run))
	{
$edit_id1=$row['post_id'];
$title=$row['post_title'];
$date=$row['post_date'];
$author=$row['post_author'];
$image=$row['post_image'];
$content=$row['post_content'];

?>
<html>
<body>
<form action="edit.php?edit_form=<?php echo $edit_id1;?>" method="post" enctype="multipart/form-data">
<table width="600" align="center" border="10">
<tr>
<td align="center" colspan="5" bgcolor="yellow"><h1>edit posts here!</h1></td>
</tr>
<tr>
<td>post title:</td>
<td><input type='text' name="title" size='30' value="<?php echo $title;?>"</td>
</tr>
<tr>
<td>post author:</td>
<td><input type="text" name="author" value="<?php echo $author;?>"</td>
</tr>
<tr>
<td>post image:</td>
<td><input type='file' name='image'</td>
<img src="../images/<?php echo $image;?>" width="60px" height="60px">
</tr>
<tr>
<td>post content:</td>
<td><textarea name='content' cols='30' rows='30' ><?php echo $content;?></textarea></td>
</tr>
<td align='center' colspan='5'><input type='submit' name='update' value='update Now'></td>
</tr>
<?php };?>
</table>
</form>
</body>
</html>
<?php
$update_id=@$_GET['edit_form'];
if(isset($_POST['update']))
{$update_id=$_GET['edit_form'];
$post_title=$_POST['title'];
$post_date=date('y-m-d');
$post_author=$_POST['author'];
$post_content=$_POST['content'];
$post_image=$_FILES['image']['name'];
$post_image_type=$_FILES['image']['type'];
$post_image_size=$_FILES['image']['size'];
$post_image_tmp=$_FILES['image']['tmp_name'];
move_uploaded_file($post_image_tmp,"../images/$post_image");
$update_query="update posts set post_title='$post_title',post_date='$post_date',post_author='$post_author',post_image='$post_image',post_content='$post_content' where post_id='$update_id'";
if(mysql_query($update_query))
{echo "<script>alert('post has been updated')</script>";
	echo "<script>window.open('index.php','_self')</script>";
	
}
}
?>