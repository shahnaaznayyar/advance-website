<div id="sidebar">
<!--email subscription box-->
<form style="border: 1 px solid;padding=3px;text-align:center;" action="http://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" 
onsubmit="window.open('http://feedburner.google.com/fb/a/mailverify?uri=onlineteacherkarachi','popupwindow','scrollbars=yes,width=550,height=520');return true">
<p>enter your  email address:</p><input type="text" style="width:140px" name="email"/></p><input type="hidden" value="onlinecomputerteacherkarachi" name="uri"/>
<input type="hidden"  name="en_us"/><input type="submit"  value="subscribe"/></p>
<div class="social">
<h2>follow us</h2>
<a href="http://www.facebook.com/onlineustaadwali target="blank""><img src="images/facebook.gif"</a>
<a href="http://www.pininterest.comabdulwali target="blank""><img src="images/pin.png"</a>
<img src="images/tweeter.png"/>
<img src="images/google.png"/>
</form>
</div>
<?php 
include("include/connect.php");
$query="select * from posts order by 1 desc LIMIT 0,5";
$run=mysql_query($query);
while($row=mysql_fetch_array($run))
{$post_id=$row['post_id'];
	$title=$row['post_title'];
$image=$row['post_image'];	
?>
<a href="pages.php?id=<?php echo $post_title;?>"><img src="images/<?php  echo $image;?>" width="150" height="150"></a>
<a href="pages.php?id=<?php echo $post_title;?>"><h2><?php echo $title;?></h2></a>
<h2><?php $title ;?></h2>
</div>
<?php };?>