<div class="navbar">
<div id="menu">
<ul>
<li><a href="index.php">home</a></li>
<li><a href="#">malala news</a></li>
<li><a href="#">malala cause</a></li>
<li><a href="#">malala photos</a></li>
<li><a href="#">about us</a></li>
<li><a href="#">mission</a></li>
<li><a href="#">contact us</a></li>
</ul>
</div>
<div class="searchbox">
<form action="search.php" method="get" >
<input type="text" size="30" name="search" placeholder="search this site">
<input type ="submit" name="submit" value="search">
</form>
</div>
</div>