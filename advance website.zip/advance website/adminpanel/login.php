<?php
session_start();
?>
<html>
<head><title>admin login</title>
</head>
<body>
<form action="login.php" method="post">
<table align="center" width="100" border="20">
<tr>
<td colspan="5" align="center" bgcolor="gray"><h1>admin login</h1></td>
</tr>
<tr>
<td>user name:</td>
<td><input type="text" name="user_name"></td>
<tr>
<td>user password:</td>
<td><input type="password" name="user_pass"></td>
</tr>
<tr>
<td><input type="submit" name="login" value="login"></td>
</tr>
</table>
</form>
</body>
</html>
<?php
include("include/connect.php");
if(isset($_post["login"]))
{
	$user_name=mysql_real_escape_string($_POST["user_name"]);
	$user_pass=mysql_real_escape_string($_POST["user_pass"]);
	$encrypt=md5($user_pass);
	$login_query="select * from admin_login where user_name='$user_name' AND userpassword='$user_pass'";
	$run=mysql_query($login_query);
	if(mysql_num_rows($run)>0)
	{$_SESSION['user_name']=$user_name;
		echo "<script>window.open('index.php','_self')</script>";
	}
	else
	{
		echo"<script>alert('username or password is incorrect')</script>";
	}
}
?>