<?php
session_start();
if(!isset($_SESSION['username']))
{
	header("location:login.php");
}
else
{
	?>
<html>
<head><title>insert new post</title>
</head>
<body>
<form action="insert_post.php" method="post" enctype="multipart/form-data">
<table width="600" align="center" border="10">
<tr>
<td align="center" colspan="5" bgcolor="yellow"><h1>insert new post here!</h1></td>
</tr>
<tr>
<td>post title:</td>
<td><input type='text' name="title" size='30'</td>
</tr>
<tr>
<td>post author:</td>
<td><input type='text' name='author'</td>
</tr>
<tr>
<td>post image:</td>
<td><input type='file' name='image'</td>
</tr>
<tr>
<td>post content:</td>
<td><textarea name='content' cols='30' rows='30'></textarea></td>
</tr>
<td align='center' colspan='5'><input type='submit' name='submit' value='publish Now'></td>
</tr>

</table>
</form>
</body>
</html>
<?php
include("include/connect.php");
if(isset($_POST['submit']))
{$title=$_POST["title"];
$date=date('y-m-d');
$author=$_POST['author'];
$content=$_POST['content'];
$image_name=$_FILES['image']['name'];
$image_type=$_FILES['image']['type'];
$image_size=$_FILES['image']['size'];
$image_tmp=$_FILES['image']['tmp'];
if($title=='' or $author=='' or $content=='')
{echo"<script>alert('any field is empty')</script>";
exit();
}
if($image_type="image/jpeg" or $image_type="image/png" or $image_type="image/gif")
{
if($image_size<=50000)
{move_uploaded_file($image_tmp,"images/$image_name");
}
else
{
echo"<script>alert('image is larger ,only less than 50kb is allowed')</script>";
}
}
else{
	echo"<script>alert('image type is invalid')</script>";
	
}
$query="insert into posts(post_title,post_date,post_author,post_image,post_content) values('$title','$date','$author','$image_name','$content')";
if($run=mysql_query($query))
{
	echo"<script>window.open('index.php?inserted=post has been inserted','_self')</script>";
}
else {
    echo "Could not successfully run query ($query) from DB: " . mysql_error();
    exit;
}
}
?>
<?php }?>