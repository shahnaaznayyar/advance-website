<?php
session_start();
if(!isset($_SESSION['username']))
{
	header("location:login.php");
}
else
{
?>

<html>
<head><title>adminpanel</title>
<link rel="stylesheet" href="admin_style.css">
</head>
<body>
<header><h1><a href="index.php">welcome to adminpanel of malala.com</a></h1></header>
<aside>
welcome:<h1><?php echo $_SESSION['user_name'];?></h1>
<h2>manage content</h2>
<h2><a href="logout_posts.php">admin logout</a></h2>
<h2><a href="index.php?view=view">view posts</a></h2>
<h2><a href="index.php?insert=insert">insert new posts</a></h2>
</aside>
<?php
if(isset($_GET['insert']))
{
	include("insert_post.php");
}

?>
<table width="900" align="center" border="3">
<tr>
<td align="center" bgcolor="orange" colspan="9"><h1>view all posts here!</h1></td>
</tr>
<tr>
<th>post no</th>
<th>post title</th>
<th>post date</th>
<th>post author</th>
<th>post image</th>
<th>post content</th>
<th>edit</th>
<th>delete</th>
</tr>
<?php
include("include/connect.php");
if(isset($_GET['view']))
{
	$query="select* from posts order by 1 DESC";
	$run=mysql_query($query);
	if(!$run){
    echo "Could not successfully run query ($query) from DB: " . mysql_error();
    exit;
}
	while($row=mysql_fetch_array($run))
	{
$id=$row['post_id'];
$title=$row['post_title'];
$date=$row['post_date'];
$author=$row['post_author'];
$image=$row['post_image'];
$content=substr($row['post_content'],0,50);
?>
<tr>
<td><?php echo "$id"?></td>
<td><?php echo "$title"?></td>
<td><?php echo"$date"?></td>
<td><?php echo"$author"?></td>
<td><img src="../images//<?php echo $image;?>" width="50px" height="50px"</td>
<td><?php echo "$content"?></td>
<td><a href="edit.php?edit=<?php echo $id;?>">edit</a></td>
<td><a href="delete.php?del=<?php echo $id;?>">delete</a></td>
<td></td>
</tr>
<?php }}; ?>
</table>
</body>
</html>
<?php }?>