<html>
<head><title>malala yousafzai</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div id="top"><p>top bar</p></div>
<div><?php include("include/header.php");?></div>
<div><?php include("include/nav.php");?></div>
<div><?php include("include/sidebar.php");?></div>
<div class="post_body">
<?Php
include("include/connect.php");
if(isset($_GET['submit']))
{    $search_id=$_GET['search'];
	$query="select * from posts where post_title like '%$search_id%'";
	$run=mysql_query($query);
	while($row=mysql_fetch_array($run))
	{
		$post_id=$row['post_id'];
		$post_title=$row['post_title'];
		$post_image=$row['post_image'];
		$post_content=substr($row['post_content'],0,100);

	
}

?>
<h2><a href="pages.php?id=<?php $post_id ;?> "><?php echo $post_title; ?></a></h2>
<center><img src="images/<?php echo $post_image;?>" width="90" height="90"></center>
<p align="justify">
<?php echo $post_content; ?>
</p>
<P align="right"><a href="pages.php?id=<?php echo $post_id;?>">read more</a></p>

<?php };?>

</div>
<div class="foot">this is footer</div>
</body