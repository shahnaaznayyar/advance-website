<html>
<head><title>malala yousafzai</title>
<link rel="stylesheet" type="text/css" href="style.css">
<script>
function myclock()
{time=new date();
hours=time.GetHours();
mins=time.GetMinutes();
sec=time.GetSeconds();
if(sec<10)
{
	sec="0"+sec;
}
if(mins<10)
{
	mins="0"+mins;
}
if(hours<10)
{
	hours="0"+hours;
}
document.getElementbyId("clock").innerHTML=hours +":"+ mins +":" +sec;
Timer=setTimeout(function(){myclock();},500);
	
}
</script>
</head>
<body onload="myclock()">
<div id="top">
<p>TODAY IS:&nbsp;&nbsp;<?php echo date('1 jS F Y');?></p>
</div>
<div><?php include("include/header.php");?></div>
<div><?php include("include/nav.php");?></div>
<div><?php include("include/sidebar.php");?></div>
<div><?php include("include/post_body.php");?></div>
<div class="foot"><p id="clock" class="clock"></P>
this is footer</div>
</body
</html>
