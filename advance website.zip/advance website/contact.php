<html>
<head><title>malala yousafzai</title>
<link rel="stylesheet" type="text/css" href="style.css">
<script>
function myclock()
{time=new date();
hours=time.getHours();
mins=time.getMinutes();
sec=time.getSeconds();
if(sec<10)
{
	sec="0"+sec;
}
if(mins<10)
{
	mins="0"+mins;
}
if(hours<10)
{
	hours="0"+hours;
}
document.getElementbyId("clock").innerHTML=hours +":"+ mins +":" +sec;
Timer=setTimeout(function(){myclock();},500);
	
}
</script>
</head>
<body onload="myclock()">
<div id="top">
<p>TODAY IS:&nbsp;&nbsp;<?php echo date("1 jS,F Y");?>

</p>
<p id="clock" class="clock"></P>
</div>
<div><?php include("include/header.php");?></div>
<div><?php include("include/nav.php");?></div>
<div><?php include("include/sidebar.php");?></div>
<div class="post_body">
<form action="contact.php" method="post">
<table width="600" border="0" align="center">
<tr>
<td align="center" colspan="5"><h2>contact us</h2></td>
</tr>
<tr>
<td>your email</td>
<td><input type="text" name="email"></input></td>
</tr>
<tr>
<td>subject</td>
<td><input type="text" name="subject"></input></td>
</tr>
<tr>
<td>your message</td>
<td><textarea cols="15" rows="10" name="message"></textarea></td>
</tr>
<tr>
<td align="center" colspan="5"><input type="submit" name="send_email" value="send email"></input></td>
</tr>
</table

</form>
</div>
<?php
if(isset($_POST["send_email"])
{
$sender_email=$_POST["email"];
$subject=$_POST["subject"];
$mes=$_POST["message"];
$message="email from:".$mes;
if($sender_email=='' or $subject=='' or $mes=='')
{
	echo"<script>alert('please fill the blank field')</script>";
	exit();
}
$to="shahnawaznayyar@gmail.com";
mail($to,$subject,$message,$sender_email);
$to_sender=$_POST['email'];
$sub="onlineustaad.com";
$mesg="thank u for sending an email,u will get to u soon";
$from="shahnawaznayyar@gmail.com";
mail($to_sender,$sub,$mesg,$from);
echo"<center><h1>email sent,get to u soon</h1></center>";
}
?>
<div class="foot"><p id="clock" class="clock"></P>
this is footer</div>
</body
</html>
